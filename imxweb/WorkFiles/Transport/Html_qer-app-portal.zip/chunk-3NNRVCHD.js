import{a}from"./chunk-2ADEKABA.js";import"./chunk-S7U364XT.js";import"./chunk-YPCFNZLI.js";export{a as ApcConfigModule};
