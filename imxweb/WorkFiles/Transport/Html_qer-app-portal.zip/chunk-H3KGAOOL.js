import{a}from"./chunk-OQ7OP25M.js";import"./chunk-S7U364XT.js";import"./chunk-YPCFNZLI.js";export{a as FrozenJobsPluginModule};
