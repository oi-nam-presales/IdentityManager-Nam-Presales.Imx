import{a}from"./chunk-DZAM5FIM.js";import"./chunk-S7U364XT.js";import"./chunk-YPCFNZLI.js";export{a as FrozenJobsPluginModule};
