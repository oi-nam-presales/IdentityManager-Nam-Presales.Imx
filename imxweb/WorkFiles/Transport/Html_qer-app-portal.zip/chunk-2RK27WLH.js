import{a}from"./chunk-XPOOS4PK.js";import"./chunk-S7U364XT.js";import"./chunk-YPCFNZLI.js";export{a as IqcConfigModule};
