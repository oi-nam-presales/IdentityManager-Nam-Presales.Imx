import{a}from"./chunk-OGRUKABU.js";import"./chunk-S7U364XT.js";import"./chunk-YPCFNZLI.js";export{a as RmbConfigModule};
