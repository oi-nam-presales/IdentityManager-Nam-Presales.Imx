import{a}from"./chunk-G7TFZOG5.js";import"./chunk-S7U364XT.js";import"./chunk-YPCFNZLI.js";export{a as RmsConfigModule};
