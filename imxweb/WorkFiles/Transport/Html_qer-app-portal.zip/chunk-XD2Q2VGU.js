import{a}from"./chunk-VARLXUGK.js";import"./chunk-YPCFNZLI.js";export{a as SacConfigModule};
