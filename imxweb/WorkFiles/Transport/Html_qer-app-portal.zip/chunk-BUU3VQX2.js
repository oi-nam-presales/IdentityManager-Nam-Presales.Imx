import{a}from"./chunk-RN5AUULB.js";import"./chunk-S7U364XT.js";import"./chunk-YPCFNZLI.js";export{a as QamConfigModule};
