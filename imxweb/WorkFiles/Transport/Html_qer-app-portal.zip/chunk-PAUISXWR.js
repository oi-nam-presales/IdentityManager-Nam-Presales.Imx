import{a}from"./chunk-DFASLXRW.js";import"./chunk-S7U364XT.js";import"./chunk-YPCFNZLI.js";export{a as HdsConfigModule};
