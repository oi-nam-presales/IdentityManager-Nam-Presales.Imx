/*
 * Public API Surface of test-plugin
 */

export * from './lib/test-plugin.service';
export * from './lib/test-plugin.component';
export * from './lib/test-plugin.module';
