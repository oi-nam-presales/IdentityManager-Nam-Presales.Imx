import { NgModule } from '@angular/core';
import { TestPluginComponent } from './test-plugin.component';



@NgModule({
  declarations: [
    TestPluginComponent
  ],
  imports: [
  ],
  exports: [
    TestPluginComponent
  ]
})
export class TestPluginModule { }
