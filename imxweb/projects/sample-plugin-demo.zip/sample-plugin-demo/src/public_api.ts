/*
 * Public API Surface of sample-plugin-demo
 */

export * from './lib/sample-plugin-demo.service';
export * from './lib/sample-plugin-demo.component';
export * from './lib/sample-plugin-demo.module';
export * from './lib/simple-ui/simple-ui.component';
